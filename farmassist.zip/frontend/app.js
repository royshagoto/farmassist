const $ = (id) => document.getElementById(id);

// Session-only conversation memory — cleared on page reload, never persisted to disk.
let conversation = [];

$("run").addEventListener("click", async () => {
  const crop = $("crop").value.trim();
  const stage = $("stage").value;
  const location = $("location").value.trim();
  const soil = $("soil").value.trim();
  const question = $("question").value.trim();

  $("err").textContent = "";
  if (!crop || !location || !question) {
    $("err").textContent = "Fill in crop, location, and your question.";
    return;
  }

  const btn = $("run");
  btn.disabled = true;
  btn.textContent = "Working...";
  $("status").textContent = "Checking weather, market prices, MSP, and asking the agent...";

  try {
    const r = await fetch("/api/recommend", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ crop, stage, location, soil, question, history: conversation }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Something went wrong.");
    $("status").textContent = "";
    conversation.push({ question, recommendation: data.recommendation });
    appendTurn(question, data.recommendation, data.trace);
    $("question").value = "";
  } catch (e) {
    $("status").textContent = "";
    $("err").textContent = e.message || String(e);
  } finally {
    btn.disabled = false;
    btn.textContent = "Get recommendation";
  }
});

$("reset").addEventListener("click", () => {
  conversation = [];
  $("output").innerHTML = "";
  $("err").textContent = "";
  $("status").textContent = "";
});

function appendTurn(question, rec, trace) {
  const flags = (rec.risk_flags || []).map((f) => `<span class="flag risk">${f}</span>`).join("");
  const turnEl = document.createElement("div");
  turnEl.className = "turn";
  turnEl.innerHTML = `
    <div class="q">${question.replace(/</g, "&lt;")}</div>
    <div class="rec">
      <h3>Recommendation</h3>
      <div class="action">${rec.recommendation || ""}</div>
      <p style="margin-top:12px;opacity:.9">${rec.reasoning || ""}</p>
      <div class="flags">
        <span class="flag">Confidence: ${rec.confidence || "—"}</span>
        ${flags}
        ${trace.turnsRemembered ? `<span class="flag">Remembering ${trace.turnsRemembered} earlier turn${trace.turnsRemembered > 1 ? "s" : ""}</span>` : ""}
      </div>
      ${rec.caveat ? `<p style="margin-top:12px;font-size:.85rem;opacity:.75">Watch for: ${rec.caveat}</p>` : ""}
    </div>
    <div class="trace">
      <h3>Data used (explainability)</h3>
      <div class="trace-item"><b>Location resolved:</b> ${trace.location} (${trace.coordinates.lat.toFixed(3)}, ${trace.coordinates.lon.toFixed(3)})</div>
      <div class="trace-item"><b>Weather (Open-Meteo, 7-day):</b> ${trace.weather}</div>
      <div class="trace-item"><b>Market (mandi prices):</b> ${trace.mandi}</div>
      <div class="trace-item"><b>MSP source (read live if relevant):</b> <a href="${trace.mspSource}" target="_blank" rel="noopener">${trace.mspSource}</a></div>
    </div>`;
  $("output").prepend(turnEl);
}
